Sam Warren
V00889558
CSC361
March 5, 2021

Programming Assignment 2

Installation
Unzip smartparser.tar.gz into your favourite directory

Running SmartParser
Run SmartParser with: python3 SmartParser.py ./sample-capture-file.cap
If you wish to test using a different .cap file, place it in the same directory as SmartParser and run it with: python3 SmartParser.py ./{your-file-name}.cap

